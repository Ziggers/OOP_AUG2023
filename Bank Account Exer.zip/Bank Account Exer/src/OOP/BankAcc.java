/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP;

/**
 *
 * @author Derek
 */
public class BankAcc {
    private int accnum;
    private int accbal;
    private String customer;
    private String email;
    private int pnum;

    public BankAcc(int accnum, int accbal, String customer, String email, int pnum) {
        this.accnum = accnum;
        this.accbal = accbal;
        this.customer = customer;
        this.email = email;
        this.pnum = pnum;
    }

    public int getAccnum() {
        return accnum;
    }

    public int getAccbal() {
        return accbal;
    }

    public String getCustomer() {
        return customer;
    }

    public String getEmail() {
        return email;
    }

    public int getPnum() {
        return pnum;
    }

    public boolean deposit(int amount) {
        if (amount > 0) {
            accbal += amount;
            return true;
        } else {
            return false;
        }
    }

    // Withdraw money from the account
    public boolean withdraw(int amount) {
        if (amount > 0 && accbal >= amount) {
            accbal -= amount;
            return true;
        } else {
            return false;
        }
    }
}
