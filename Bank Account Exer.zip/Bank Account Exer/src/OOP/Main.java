/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP;

/**
 *
 * @author Derek
 */
public class Main {
    public static void main(String[] args) {
    BankAcc account = new BankAcc(123456, 1000, "Ziggy Sy", "ziggy@example.com", 123456789);

    boolean depositSuccess = account.deposit(500);
    if (depositSuccess) {
        System.out.println("Deposit successful. Updated Account Balance: $" + account.getAccbal());
    } else {
        System.out.println("Deposit failed. Invalid amount.");
    }

    boolean withdrawSuccess = account.withdraw(300);
    if (withdrawSuccess) {
        System.out.println("Withdrawal successful. Updated Account Balance: $" + account.getAccbal());
    } else {
        System.out.println("Withdrawal failed. Invalid amount or insufficient balance.");
    }
    
    System.out.println("Updated Account Number: " + account.getAccnum());
    System.out.println("Updated Account Balance: $" + account.getAccbal());
    System.out.println("Customer: " + account.getCustomer());
    System.out.println("Email: " + account.getEmail());
    System.out.println("Phone Number: " + account.getPnum());
}
}
