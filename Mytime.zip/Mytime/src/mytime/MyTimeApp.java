package mytime;

public class MyTimeApp {

    public static void main(String[] args) {
        MyTime myTime = new MyTime(1, 23, 1, true);
        
        System.out.println("Time Given:");
        myTime.displayTime12();
        
        System.out.println("\nFast forward 1 second:");
        myTime.tickBySecond();
        myTime.displayTime12();
        
        System.out.println("\nFast forward 1 minute:");
        myTime.tickByMinute();
        myTime.displayTime12();
        
        System.out.println("\nFast forward 1 hour:");
        myTime.tickByHour();
        myTime.displayTime12();
    }
}


